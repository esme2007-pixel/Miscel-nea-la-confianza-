// MODAL de promociones
const modal = document.getElementById("modalPromo");
const btn = document.getElementById("verPromociones");
const span = modal.querySelector(".cerrar");

btn.onclick = () => {
  modal.style.display = "block";
  modal.setAttribute('aria-hidden', 'false');
};
span.onclick = () => {
  modal.style.display = "none";
  modal.setAttribute('aria-hidden', 'true');
};
window.onclick = (e) => {
  if (e.target === modal) {
    modal.style.display = "none";
    modal.setAttribute('aria-hidden', 'true');
  }
};

// CARRITO
let carrito = [];
const botonesAgregar = document.querySelectorAll(".agregar");
const listaCarrito = document.getElementById("lista-carrito");
const total = document.getElementById("total");
const contador = document.getElementById("contador");

const abrirCarrito = document.getElementById("abrirCarrito");
const cerrarCarrito = document.getElementById("cerrarCarrito");
const carritoDiv = document.getElementById("carrito");
const pagarBtn = document.getElementById("pagarBtn");
const vaciarBtn = document.getElementById("vaciarCarritoBtn");

botonesAgregar.forEach(btn => {
  btn.addEventListener("click", (e) => {
    const producto = e.target.closest(".producto");
    const nombre = producto.dataset.nombre;
    const precio = parseFloat(producto.dataset.precio);
    carrito.push({ nombre, precio });
    actualizarCarrito();
  });
});

abrirCarrito.onclick = () => carritoDiv.classList.toggle("oculto");
cerrarCarrito.onclick = () => carritoDiv.classList.add("oculto");

pagarBtn.onclick = () => {
  if (carrito.length === 0) {
    alert("Tu carrito está vacío.");
    return;
  }
  carrito = [];
  actualizarCarrito();
  carritoDiv.classList.add("oculto");
  mostrarMensajeExito("¡Compra realizada con éxito!");
};

vaciarBtn.onclick = () => {
  carrito = [];
  actualizarCarrito();
};

function actualizarCarrito() {
  listaCarrito.innerHTML = "";
  let totalPrecio = 0;
  carrito.forEach(p => {
    totalPrecio += p.precio;
    const li = document.createElement("li");
    li.textContent = `${p.nombre}  $${p.precio.toFixed(2)}`;
    listaCarrito.appendChild(li);
  });
  total.textContent = totalPrecio.toFixed(2);
  contador.textContent = carrito.length;
}

// ACORDEÓN
document.querySelectorAll(".acordeon-titulo").forEach(btn => {
  btn.onclick = () => {
    const item = btn.parentElement;
    const contenido = item.querySelector(".acordeon-contenido");
    const isActive = item.classList.contains("activo");

    // Cerrar todos
    document.querySelectorAll(".acordeon-item").forEach(i => {
      i.classList.remove("activo");
      const c = i.querySelector(".acordeon-contenido");
      if (c) {
        c.style.display = "none";
        i.querySelector(".acordeon-titulo").setAttribute('aria-expanded', 'false');
        c.setAttribute('hidden', '');
      }
    });

    if (!isActive) {
      item.classList.add("activo");
      if (contenido) {
        contenido.style.display = "block";
        btn.setAttribute('aria-expanded', 'true');
        contenido.removeAttribute('hidden');
      }
    }
  };
});

// MENSAJE DE ÉXITO PRINCIPAL
function mostrarMensajeExito(text) {
  const mensaje = document.getElementById("mensajeExito");
  mensaje.textContent = text;
  mensaje.classList.remove("oculto");
  setTimeout(() => mensaje.classList.add("oculto"), 2500);
}

// FORMULARIO MENSAJE DIRECTO
const formMensaje = document.getElementById("formMensaje");
const mensajeConfirmacion = document.getElementById("mensajeConfirmacion");

formMensaje.addEventListener("submit", (e) => {
  e.preventDefault();

  // Validación simple (ya HTML required lo hace, esto es complemento)
  const nombre = formMensaje.nombre.value.trim();
  const correo = formMensaje.correo.value.trim();
  const mensaje = formMensaje.mensaje.value.trim();

  if (nombre === "" || correo === "" || mensaje === "") {
    alert("Por favor llena todos los campos.");
    return;
  }

  // Aquí podrías conectar con backend o API para enviar mensaje.
  // Por el momento solo mostramos confirmación.

  formMensaje.reset();
  mensajeConfirmacion.classList.remove("oculto");

  setTimeout(() => {
    mensajeConfirmacion.classList.add("oculto");
  }, 4000);
});
